unzip the dyf files into this folder.

Install dependencies.